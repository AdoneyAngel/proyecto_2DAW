export const apiUrl = "http://localhost:8000/api"
export const prefix = "v1"
