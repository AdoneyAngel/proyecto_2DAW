enum MemberTypeEnum {
  Admin = 1,
  Member = 2,
  Viewer = 3
}

export default MemberTypeEnum
