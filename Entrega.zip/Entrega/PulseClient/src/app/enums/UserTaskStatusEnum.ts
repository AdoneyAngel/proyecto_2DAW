enum UserTaskStatusEnum {
  Todo=1,
  Progress=2,
  Done=3
}

export default UserTaskStatusEnum
