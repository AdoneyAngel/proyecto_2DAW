enum TaskStatusEnum {
  Todo=1,
  Progress=2,
  Review=3,
  Done=4
}

export default TaskStatusEnum
