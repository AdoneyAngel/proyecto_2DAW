import { Component } from '@angular/core';

@Component({
  selector: 'app-content-box-simple-delimiter',
  standalone: true,
  imports: [],
  templateUrl: './content-box-simple-delimiter.component.html',
  styleUrl: './content-box-simple-delimiter.component.css'
})
export class ContentBoxSimpleDelimiterComponent {

}
