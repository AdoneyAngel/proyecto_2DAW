export const environment = {
  production: false,
  GOOGLE_CLIENT_ID: "291569747823-ro6hcogju6tadvfuoep11dt1pk4vgop1.apps.googleusercontent.com"
};
