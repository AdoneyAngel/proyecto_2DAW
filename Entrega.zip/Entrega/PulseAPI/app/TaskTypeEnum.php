<?php

namespace App;

enum TaskTypeEnum: string
{
    case Task = "task";
    case Issue = "issue";
}
